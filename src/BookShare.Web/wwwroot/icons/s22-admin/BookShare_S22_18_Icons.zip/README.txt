BookShare S22 - 18 SVG icons

Gồm 18 icon SVG tùy chỉnh. Đường dẫn tích hợp trong dự án ASP.NET: wwwroot/icons/s22-admin/

Danh sách: audit.svg, book-open.svg, calendar.svg, chart.svg, coins.svg, dashboard.svg, gem.svg, library.svg, loan.svg, lock.svg, palette.svg, robot.svg, roles.svg, settings.svg, shield.svg, unlock.svg, users.svg, wallet.svg
